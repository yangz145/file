/**
 * Machine Service Logger - Client-Side JavaScript
 */

console.log('Service Logger initialized');

// 1️⃣ DOM references
const form = document.getElementById('serviceForm');
const logsContainer = document.getElementById('logs');

// 2️⃣ Fetch existing logs from API
async function fetchLogs() {
    try {
        const response = await fetch('/api/services.php');
        if (!response.ok) throw new Error('Failed to fetch logs');

        const logs = await response.json();
        displayLogs(logs);
    } catch (error) {
        console.error('Error fetching logs:', error);
        logsContainer.innerHTML = '<p class="error">Failed to load service logs.</p>';
    }
}

// 3️⃣ Display logs in the UI
function displayLogs(logs) {
    logsContainer.innerHTML = '';

    if (!logs.length) {
        logsContainer.innerHTML = '<p class="empty-state">No service logs yet.</p>';
        return;
    }

    logs.forEach(log => {
        const entry = document.createElement('div');
        entry.className = 'log-item';
        entry.innerHTML = `
            <div class="log-meta">
                <strong>${log.technician}</strong> | ${log.service_date}
            </div>
            <div class="log-notes">
                ${log.notes}
            </div>
        `;
        logsContainer.appendChild(entry);
    });
}

// 4️⃣ Validate form fields
function validateForm(data) {
    const errors = [];
    if (!data.get('technician').trim()) errors.push('Technician name is required.');
    if (!data.get('service_date').trim()) errors.push('Service date is required.');
    if (!data.get('notes').trim()) errors.push('Service notes are required.');
    return errors;
}

// 5️⃣ Show messages in the UI
function showMessage(message, type = 'error') {
    logsContainer.innerHTML = `<p class="${type}">${message}</p>`;
}

// 6️⃣ Submit form
async function submitLog(event) {
    event.preventDefault(); // stop page reload

    const formData = new FormData(form);
    const errors = validateForm(formData);

    if (errors.length) {
        showMessage(errors.join('<br>'), 'error');
        return;
    }

    try {
        const response = await fetch('/api/services.php', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const errData = await response.json();
            const errMsg = errData.error ? errData.error.join ? errData.error.join('<br>') : errData.error : 'Failed to submit log';
            throw new Error(errMsg);
        }

        const logs = await response.json();
        displayLogs(logs);
        form.reset(); // clear form on success
    } catch (error) {
        console.error('Error submitting log:', error);
        showMessage(error.message, 'error');
    }
}

// 7️⃣ Event listener
form.addEventListener('submit', submitLog);

// 8️⃣ Initialize on page load
fetchLogs();
