<?php
/**
 * Machine Service Logger - API Endpoint
 * Fully implemented for GET and POST
 */

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$dataFile = __DIR__ . '/../data/services.json';

// Read logs from file
function readLogs() {
    global $dataFile;
    if (!file_exists($dataFile)) return [];
    $jsonData = file_get_contents($dataFile);
    $logs = json_decode($jsonData, true);
    return is_array($logs) ? $logs : [];
}

// Write logs to file
function writeLogs($logs) {
    global $dataFile;
    file_put_contents($dataFile, json_encode($logs, JSON_PRETTY_PRINT));
}

// Validate incoming log data
function validateLogData($data) {
    $required = ['technician', 'service_date', 'notes'];
    $errors = [];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            $errors[] = "$field is required.";
        }
    }
    return $errors;
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {

    case 'GET':
        try {
            $logs = readLogs();
            http_response_code(200);
            echo json_encode($logs);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to read logs: ' . $e->getMessage()]);
        }
        break;

    case 'POST':
        // Read input
        $data = $_POST;

        // Validate
        $errors = validateLogData($data);
        if (!empty($errors)) {
            http_response_code(400);
            echo json_encode(['error' => $errors]);
            exit();
        }

        // Create new log
        $logs = readLogs();

        $newLog = [
            'id' => uniqid(),
            'technician' => htmlspecialchars($data['technician']),
            'service_date' => $data['service_date'],
            'notes' => htmlspecialchars($data['notes']),
            'created_at' => date('c')
        ];

        $logs[] = $newLog;
        writeLogs($logs);

        http_response_code(201);
        echo json_encode($logs); // return all logs for JS to render
        break;

    case 'PUT':
        http_response_code(501);
        echo json_encode(['error' => 'PUT method not yet implemented']);
        break;

    case 'DELETE':
        http_response_code(501);
        echo json_encode(['error' => 'DELETE method not yet implemented']);
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
}
